#include<stdio.h>

int main()
{
    int age = 18;
    printf("I'm Vaneesa T. Escarpe, Age of %d years old", age);
    return 0;
}